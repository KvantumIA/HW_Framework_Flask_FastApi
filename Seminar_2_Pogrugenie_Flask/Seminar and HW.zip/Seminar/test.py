account = {'login': 'Ivan', 'password': 1234}
if 'Ivan' == account.get('login'):
    print('yes')